<?php
/*
Plugin Name: Stealth Mode WP
Description: Oculta WordPress, Elementor y detalles del servidor ante herramientas de fingerprinting como Wappalyzer.
Version: 1.0
Author: Aitor
*/

if (!defined('ABSPATH')) exit;

// Ocultar versión y meta generator
remove_action('wp_head', 'wp_generator');
add_filter('the_generator', '__return_empty_string');

// Ocultar versiones en scripts y estilos
function stealth_remove_versions($src) {
    return remove_query_arg('ver', $src);
}
add_filter('script_loader_src', 'stealth_remove_versions', 9999);
add_filter('style_loader_src', 'stealth_remove_versions', 9999);

// Eliminar cabeceras del servidor
add_action('send_headers', function () {
    header_remove('X-Powered-By');
    header_remove('Server');
    header_remove('X-Pingback');
});

// Eliminar wp-emoji, oEmbed y otros scripts reveladores
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'wp_oembed_add_discovery_links');
remove_action('wp_head', 'rest_output_link_wp_head');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('template_redirect', 'rest_output_link_header', 11);

// Ocultar barra de admin si no está logueado
add_action('after_setup_theme', function () {
    if (!is_user_logged_in()) show_admin_bar(false);
});

// Bloquear acceso a /readme.html y /license.txt
add_action('template_redirect', function () {
    if (preg_match('#/(readme\.html|license\.txt)$#', $_SERVER['REQUEST_URI'])) {
        status_header(404); exit;
    }
});

// Bloquear REST API para no logueados (oculta /wp-json)
add_filter('rest_authentication_errors', function($access) {
    if (!is_user_logged_in()) {
        return new WP_Error('rest_cannot_access', 'Access denied.', array('status' => 403));
    }
    return $access;
});

// Ocultar clases sospechosas del body
add_filter('body_class', function ($classes) {
    return array_filter($classes, function ($class) {
        return !preg_match('/^(wp-|elementor|e-|admin-)/i', $class);
    });
});

// Eliminar meta generator y comentarios HTML de Elementor
add_action('init', function () {
    if (class_exists('\Elementor\Plugin')) {
        remove_action('wp_head', [\Elementor\Plugin::$instance, 'print_head_tag']);
    }
});

// Eliminar comentarios HTML de Elementor
add_action('wp_footer', function () {
    ob_start(function ($html) {
        return preg_replace('/<!--.*?Elementor.*?-->/s', '', $html);
    });
}, 0);

// Ocultar Elementor del admin
add_action('admin_menu', function () {
    remove_menu_page('elementor');
});
